import mongoose from 'mongoose';
import express from 'express';
const app=express();
mongoose.connect("mongodb://localhost:27017/MailUserDataBase").then(() => {
    console.log('Connected to MongoDB');
}).catch((err) => {
    console.log('Failed to connect to MongoDB', err);
});
const userSchema= new mongoose.Schema({
    firstName:{
        type: String,
        required: true,
    },
    lastname:{
        type:String,
    },
    email:{
        type:String,
        required:true,
        unique:true,
    },
    phoneNo:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true,
    }
})
export const USER= mongoose.model("user",userSchema);
app.listen(3001,()=>{
    console.log("server is running");
})