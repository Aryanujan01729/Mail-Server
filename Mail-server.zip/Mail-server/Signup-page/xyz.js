import {createUser} from './Signup-backend.js'
document.getElementById("signupBtn").addEventListener("submit",signup)
 function signup()
  {
      const FirstName=document.querySelector(".First-Name");
      const LastName=document.querySelector(".last-Name");
      const Mobile=document.querySelector(".Mobile");
      const email=document.querySelector(".E-Mail");
      const pass=document.querySelector(".Password");
      const conpass=document.querySelector(".ConfirPass");
      if(pass.value!==conpass.value)
      {
          console.log("Password and Confirm Password does not match");
      }
      console.log(FirstName.value);
      console.log(LastName.value);
      console.log(Mobile.value);
      console.log(email.value);
      console.log(pass.value);
      console.log(conpass.value);
      createUser(FirstName.value,LastName.value,email.value,Mobile.value,pass.value);
}