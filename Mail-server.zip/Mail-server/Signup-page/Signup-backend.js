
import {USER} from './NewUser.js';
// async function createUser() {
//   await USER.create({
//       firstName:"Kanis",
//       lastname:"Maheshwa",
//       email:"kanishkmahesh@gmail.com",
//       phoneNo:"9956412",
//       password:"123456"
//   });
//   console.log('User created successfully');
// }

async function createUser(fn,ln,mailid,mno,pass) 
{
    await USER.create({
        firstName:fn,
        lastname:ln,
        email:mailid,
        phoneNo:mno,
        password:pass
    });
    console.log('User created successfully');
}
export {createUser} ;

    
    