const SMTPServer= require("smtp-server").SMTPServer;
const server= new SMTPServer({
    allowInsecureAuth:true,
    authOptional: true,
    onConnect(session,cb)
    {
        console.log('onConnect',session.id)
        cb()
    },
    onMailFrom(address, session, cb)
    {
        console.log('onMailFrom',address.address, session.id)
        cb()
    },
    onRcptTo(address, session,cb)
    {
        console.log('onReceptTo',address.address,session.id)
    },
    onData(stream,session,cb)
    {
        console.log("************************")
        stream.on('data',(data)=>console.log('ondata ${data.toString()}'));
        stream.on('end', cb);
    }
});

server.listen(25, ()=>console.log('Server Running on 25'));
server.timeout = 300000;