/*const nodemailer = require('nodemailer');

// Create a transporter
const transporter = nodemailer.createTransport({
    host: 'localhost',
    port: 25, // or the port your SMTP server is listening on
    secure: false, // true for 465, false for other ports
    tls: {
        rejectUnauthorized: false
    }
});

// Setup email data
const mailOptions = {
    from: '"Test Sender" <test@example.com>', // sender address
    to: 'recipient@example.com', // list of receivers
    subject: 'Hello', // Subjectl@gmail.comine
    text: 'Hello world?', // plain text body
    html: '<b>Hello world?</b>' // html body
};

// Send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log(error,"*******");
    }
    else
    {
        console.log('Message sent: %s', info.messageId);
    }
});*/
import {USER} from './NewUser.js';
async function createUser() {
    await USER.create({
        firstName:"Kanis",
        lastname:"Maheshwa",
        email:"kanishkmahesh@gmail.com",
        phoneNo:"9956412",
        password:"123456"
    });
    console.log('User created successfully');
}
createUser();

