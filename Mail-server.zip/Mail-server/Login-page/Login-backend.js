import mongoose from 'mongoose'
function Andar()
{
    mongoose.connect("mongodb://localhost:27017/MailUserDataBase").then(() => {
        console.log('Connected to MongoDB');
    }).catch((err) => {
        console.log('Failed to connect to MongoDB', err);
    });
    const database = client.db('MailUserDataBase');
    const collection = database.collection('user');
}


